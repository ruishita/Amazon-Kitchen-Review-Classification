#Tao Ruishi
#ITP 499 Fall 2021
#Final Project

import pandas as pd
import tensorflow as tf
import numpy as np
import re
import contractions

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn import metrics
import matplotlib.pyplot as plt

import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
nltk.download('stopwords')
nltk.download('wordnet')

# 1.	Create a DataFrame “review_data” to store the reviews data. The data are separated by tabs in the tsv file.
review_data = pd.read_csv('amazon_reviews_us_Kitchen_v1_00.tsv', sep='\t', on_bad_lines='skip', dtype={'review_body': str})

# 2.	Print 10 rows of data frame. 
print(review_data.head(10))

# 3.	In the data frame retain the columns “review_body” and “star_rating”.
review_data = review_data[['review_body', 'star_rating']]
print(review_data.head(10))
print('Total number of reviews: ', len(review_data))

# 4.    Creating dataframes of positive reviews and negtive reviews.
positive_df = review_data[review_data['star_rating']>3]
negtive_df = review_data[review_data['star_rating']<3]

# 5.    Randomly select 100,000 positive reviews and 100,000 negative reviews. Create the target variable. Combine them into a new dataframe.
positive_df['target'] = 1
negtive_df['target'] = 0

data = positive_df.sample(100000, random_state=2021).append(negtive_df.sample(100000, random_state=2021))
data.drop('star_rating', inplace=True, axis=1)
print(data)

# 6.	Calculate the average word length of all the reviews present in the data frame. Also print the first three lines in the data frame.
def calculate_avg_length(df):
    word_count = 0
    word_length = 0
    for review in df['review_body'].tolist():
        for word in review.split(' '):
            word_count += 1
            word_length += len(word)
    return word_length / word_count

data['review_body'] = data['review_body'].astype(str)
avg_len = calculate_avg_length(data)
print('Average word length of all the reviews: ', avg_len)
print(data.head(3))

# 7.	Perform Data Cleaning

def cleaning(review):
    # a.	Convert all the reviews to lowercase
    s = review.lower()
    pattern = re.compile(r'http[s]*://\S+|[^a-z \']| +')
    # b.c.	Remove URLs and non-alphabetical characters from the reviews
    s = pattern.sub(' ', s)
    # d.	Remove extra spaces between words
    s = pattern.sub(' ', s)
    # e.	Perform contractions on the reviews
    s = ' '.join([contractions.fix(word) for word in s.split(' ')])
    return s

# example = "I like this one http://www.bing.com, it only need 10$, CHECK IT!!!!! it's really nice  $$$emoji!"
# print(cleaning(example))

data['review_body'] = data.apply(lambda x: cleaning(x.review_body), axis=1)
print(data.head(10))

# 8.	Perform Data Pre-processing

wnl = WordNetLemmatizer()
def preprocess(review):
    words = review.split(' ')
    # a.	Remove stop words
    # b.    Perform Lemmatization
    words = [wnl.lemmatize(word) for word in words if word not in stopwords.words('english')]
    return ' '.join(words)

data['review_body'] = data.apply(lambda x: preprocess(x.review_body), axis=1)
print(data.head(10))

# 9.	Calculate the average word length of all the reviews in the data frame and print the first three lines in data frame, similar to step 6.
new_avg_len = calculate_avg_length(data)
print('Average word length of all the reviews after pre-processing: ', new_avg_len)
print(data.head(3))

# 10.	Partition dataset into train and test, using sklearn train_test_split, random_state = 2021. Test_size = 0.2
train, test = train_test_split(data, test_size=0.2, random_state=2021)
X_train, y_train = train['review_body'], train['target']
X_test, y_test = test['review_body'], test['target']
print('Training set size: ', len(train), '\n', train.head(5))
print('Test set size: ', len(test), '\n', test.head(5))

# 11.	Extract the tfidf features from X_train and X_test using sklearn TfidfVectorizer.
vectorizer = TfidfVectorizer()

tfidfs = vectorizer.fit_transform(X_train.append(X_test))
X_train, X_test = tfidfs[:160000], tfidfs[160000:]
print(X_train, X_test)


# 12.	Train a Multinomial Naive Bayes model on training data set using sklearn’s built in implementation
clf = MultinomialNB()
clf.fit(X_train, y_train)

train_predicted = clf.predict(X_train)
print("MultinomialNB Accuracy on trainset" , metrics.accuracy_score(y_train,train_predicted))


# 13.	Now test the model using testing data and print the accuracy score.
test_predicted = clf.predict(X_test)
print("MultinomialNB Accuracy on testset" , metrics.accuracy_score(y_test,test_predicted))

# 14.	Plot the confusion matrix (as a figure). 
metrics.plot_confusion_matrix(clf, X_test, y_test)
plt.show()

# 15.	Prompt the user to enter a review. Then print its sentiment.
review = input(print('please enter a review: '))
review = cleaning(review)
review = ' '.join([wnl.lemmatize(word) for word in review.split(' ') if word not in stopwords.words('english')])
vec = vectorizer.transform([review])

print('Predicted', clf.predict(vec))